-- for my understanding i created a  database with collge name 
create database College;

-- I checked the database is created or not 
show databases;

-- Created a firtst table 
create table Students(ID int, Name varchar(20)); 

insert into Students(ID, Name) values (1, 'Ashley');
insert into Students(ID, Name) values (2, 'Samantha');
insert into Students(ID, Name) Values (3, 'Julia');
insert into Students(ID, Name) values(4, 'Scarlet');

show tables;

-- Created a second table 
select * from Students;

create table Friends(ID int, Friend_ID int);

Insert into Friends(ID, Friend_ID) values (1, 2);
Insert into Friends(ID, Friend_ID) values (2, 3);
Insert into Friends(ID, Friend_ID) values (3, 4);
Insert into Friends(ID, Friend_ID) values (4, 1);

show tables;

-- created a third table
select * from friends;

create table Packages(ID int, Salary float8);

insert into Packages(ID, Salary) Values (1, 15.2);
insert into Packages(ID, Salary) Values (2, 10.06);
insert into Packages(ID, Salary) Values (3, 11.55);
insert into Packages(ID, Salary) Values (4, 12.12);

show tables;

select * from packages;

-- Task 1 solution 

WITH CTE2 AS 
(SELECT CASE 
			when pa.salary > ps.salary then st.name 
            end as name_salary, pa.salary 
from students as st
inner join friends as f on st.ID = f.ID
inner join packages as ps on st.ID = ps.ID
inner join packages as pa on f.Friend_ID = pa.ID) 
select name_salary
from CTE2
where name_salary is not null 
order by salary;


