create table student_data(ID int, Name varchar(20), Marks int); 

insert into student_data(ID, Name, Marks) values (1, 'Alice', 85);
insert into student_data(ID, Name, Marks) values (2, 'BOb', 90);
insert into student_data(ID, Name, Marks) values (3, 'Carol', 75);
insert into student_data(ID, Name, Marks) values (4, 'Dave', 80);
insert into student_data(ID, Name, Marks) values (5, 'Eve', 70);
insert into student_data(ID, Name, Marks) values (6, 'Frank', 95);

show tables;

select * from student_data;

UPDATE student_data
JOIN (
    SELECT 
        Id,
        CASE
            WHEN Id % 2 = 1 THEN (SELECT Name FROM (SELECT * FROM student_data) AS sm WHERE sm.Id = student_data.Id + 1)
            WHEN Id % 2 = 0 THEN (SELECT Name FROM (SELECT * FROM student_data) AS sm WHERE sm.Id = student_data.Id - 1)
        END AS newName,
        CASE
            WHEN Id % 2 = 1 THEN (SELECT Marks FROM (SELECT * FROM student_data) AS sm WHERE sm.Id = student_data.Id + 1)
            WHEN Id % 2 = 0 THEN (SELECT Marks FROM (SELECT * FROM student_data) AS sm WHERE sm.Id = student_data.Id - 1)
        END AS newMarks
    FROM student_data
) AS derived
ON student_data.Id = derived.Id
SET student_data.Name = derived.newName,
    student_data.Marks = derived.newMarks;